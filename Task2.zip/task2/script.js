document.addEventListener("click", handleMouseClick)

const MAX_NUMBER_LENGTH = 26;

const left_operand = document.querySelector("[data-left-operand]")
const right_operand = document.querySelector("[data-right-operand]")
const operator = document.querySelector("[data-operator]")

function calculate(leftoperand, operator, rightoperand)
{
    var leftInt = parseFloat(leftoperand)
    var rightInt = parseFloat(rightoperand)
    if(operator === '+')
    {
        return rightInt+ leftInt;
    } else if(operator === '-')
    {
        return rightInt-leftInt;
    } else if(operator === '×')
    {
        return rightInt * leftInt;
    }
    else if(operator === '÷')
    {
        return rightInt/leftInt;
    }
}



function handleMouseClick(e) {
    if(e.target.matches("[data-number]"))
    {
        addToDisplay(e.target.innerText)
    }

    if(e.target.matches("[data-ac]"))
    {
        clearDisplay()
    }

    if(e.target.matches("[data-operator]"))
    {
        addOperator(e.target.innerText);
    }

    if(e.target.matches("[data-delete]"))
    {
        left_operand.innerText = left_operand.innerText.substring(0, left_operand.innerText.length-1); 
    }

    if(e.target.matches("[data-equals]"))
    {
        var calcValue = calculate(left_operand.innerText, operator.innerText, right_operand.innerText)
        clearDisplay();
        left_operand.innerText = calcValue;
    }
}

function addOperator(operatorValue)
{
    console.log(operator.innerText)
    if(left_operand.innerText.length <= 0 && operator.innerText === "") return

    if(right_operand.innerText.length <=0)
    {
        right_operand.innerText = left_operand.innerText;
        left_operand.innerText = ""
    }
    
    
    operator.innerText = operatorValue;
}

function addToDisplay(number)
{
    if(left_operand.innerText.length >= MAX_NUMBER_LENGTH) return
    if([...left_operand.innerText].some(character => character === ".") && number === ".") return

    left_operand.innerText += number
}

function clearDisplay()
{
    left_operand.innerText = ""
    right_operand.innerText = ""
    operator.innerText = ""
}